package com.example.cs360_project_2;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class PermissionPromptActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 1;
    private static final String NOTIFICATION_CHANNEL_ID = "weight_goal_notification";
    private static final String NOTIFICATION_CHANNEL_NAME = "Weight Goal Notifications";

    private static final int NOTIFICATION_ID_GOAL_REACHED = 1123;
    private Button buttonRequestPermission;
    private boolean isNotificationChannelCreated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_prompt);

        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);

        buttonRequestPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.action_data_display) {
                    // Handle home click
                    Toast.makeText(PermissionPromptActivity.this, "Data Display clicked", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(PermissionPromptActivity.this, DataDisplayActivity.class);
                    startActivity(intent);
                    return true;
                } else if (itemId == R.id.action_sms_permission) {
                    // Handle profile click
                    Toast.makeText(PermissionPromptActivity.this, "SMS clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.action_logout) {
                    // Handle settings click
                    Toast.makeText(PermissionPromptActivity.this, "Logout clicked", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(PermissionPromptActivity.this, LoginActivity.class);
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        createNotificationChannel();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            setupWeightGoalNotification();
        } else {
            // Permission not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                setupWeightGoalNotification();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                // App can continue functioning without providing notifications
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    NOTIFICATION_CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notification channel for weight goal reminders");

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            isNotificationChannelCreated = true;
        }
    }

    private void setupWeightGoalNotification() {
        if (!isNotificationChannelCreated) {
            createNotificationChannel();
        }

        DatabaseHelper dbHelper = DatabaseHelper.getInstance(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {DatabaseHelper.COLUMN_DATE, DatabaseHelper.COLUMN_WEIGHT};
        Cursor weightData = db.query("weight", projection, null, null, null, null, null);
        double goalWeight = 0.0;
        boolean goalWeightReached = false;
        Log.i("mytag", "test1");
        // Find the goal weight from the database
        if (weightData.moveToFirst()) {
            Log.i("mytag", "test2");
            do {
                int dateDataInt = weightData.getColumnIndex(DatabaseHelper.COLUMN_DATE);
                int weightDataInt = weightData.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT);
                if (dateDataInt > 0 && weightDataInt > 0) {
                    String date = weightData.getString(dateDataInt);
                    String weight = weightData.getString(weightDataInt);

                    if (date.equalsIgnoreCase("goal")) {
                        goalWeight = Double.parseDouble(weight);
                        break;
                    }
                }
            } while (weightData.moveToNext());
        }
        weightData.close();
        Log.i("mytag", "test3");
        // Check if any weights have reached the goal weight
        weightData = dbHelper.getWeightData();
        if (weightData.moveToFirst()) {
            do {
                Log.i("mytag", "test4");
                int dateDataInt = weightData.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE);
                int weightDataInt = weightData.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT);

                String date = weightData.getString(dateDataInt);
                    String weight = weightData.getString(weightDataInt);
                    Log.i("mytag", date);
                    if (!date.equalsIgnoreCase("goal")) {
                        Log.i("mytag", "test5");
                        double currentWeight = Double.parseDouble(weight);
                        if (currentWeight >= Double.parseDouble(String.valueOf(goalWeight))) {
                            Log.i("mytag", "goal weight rrrrrrrrrrrrreached");
                            goalWeightReached = true;
                            break;
                        }else {
                            Log.i("mytag", "goal weight not rrrrrrrrrrrrrreached");
                        }

                }

            } while (weightData.moveToNext());
        }
        weightData.close();
        if (goalWeightReached) {
            Log.i("mytag", "goal weight reached");
            // Goal weight reached, create a notification
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("Weight Goal Reached")
                    .setContentText("Congratulations! You have reached your weight goal.")
                    .setPriority(NotificationCompat.PRIORITY_HIGH);

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
            notificationManager.notify(NOTIFICATION_ID_GOAL_REACHED, builder.build());
        }
    }

}

