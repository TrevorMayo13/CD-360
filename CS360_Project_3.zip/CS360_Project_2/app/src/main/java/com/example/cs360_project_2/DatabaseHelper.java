package com.example.cs360_project_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 4;
    private static final String DATABASE_NAME = "project3.db";
    private static final String TABLE_NAME = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String TABLE_WEIGHT = "weight";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " ("
                + COLUMN_USERNAME + " TEXT PRIMARY KEY,"
                + COLUMN_PASSWORD + " TEXT)";

        db.execSQL(createTableQuery);

        String createWeightTableQuery = "CREATE TABLE " + TABLE_WEIGHT + " ("
                + COLUMN_DATE + " TEXT,"
                + COLUMN_WEIGHT + " TEXT)";

        db.execSQL(createWeightTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades if necessary
    }

    public Cursor getWeightData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_WEIGHT;
        return db.rawQuery(query, null);
    }

    public long addWeightData(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        return db.insert(TABLE_WEIGHT, null, values);
    }

    public int deleteRow(String date, String weight) {
        SQLiteDatabase db = getWritableDatabase();
        String whereClause = COLUMN_DATE + " = ? AND " + COLUMN_WEIGHT + " = ?";
        String[] whereArgs = {date, weight};
        return db.delete(TABLE_WEIGHT, whereClause, whereArgs);
    }

}
