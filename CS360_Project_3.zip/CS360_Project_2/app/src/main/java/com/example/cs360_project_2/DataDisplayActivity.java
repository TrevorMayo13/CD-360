package com.example.cs360_project_2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DataDisplayActivity extends AppCompatActivity implements AddDataDialogFragment.AddDataDialogListener {

    private Button buttonAddData;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        buttonAddData = findViewById(R.id.buttonAddData);
        TextView editTextWeightGoal = findViewById(R.id.editTextWeightGoal);
        Button buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        databaseHelper = DatabaseHelper.getInstance(DataDisplayActivity.this);

        // Retrieve the weight goal from the database and populate the EditText
        String weightGoal = getWeightGoal();
        editTextWeightGoal.setText(weightGoal);

        buttonSaveGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightGoal = editTextWeightGoal.getText().toString();
                if (!weightGoal.isEmpty()) {
                    saveWeightGoal(weightGoal);
                }
            }
        });
        buttonAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddDataDialogFragment dialog = new AddDataDialogFragment();
                dialog.setListener(DataDisplayActivity.this); // Set the listener
                dialog.show(getSupportFragmentManager(), "AddDataDialog");
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.action_data_display) {
                    // Handle home click
                    Toast.makeText(DataDisplayActivity.this, "Data Display clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.action_sms_permission) {
                    // Handle profile click
                    Toast.makeText(DataDisplayActivity.this, "SMS clicked", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(DataDisplayActivity.this, PermissionPromptActivity.class);
                    startActivity(intent);
                    return true;
                } else if (itemId == R.id.action_logout) {
                    // Handle settings click
                    Toast.makeText(DataDisplayActivity.this, "Logout clicked", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(DataDisplayActivity.this, LoginActivity.class);
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        // Retrieve data from the SQLite database and populate the table
        populateTable();
    }

    private String getWeightGoal() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String[] projection = {DatabaseHelper.COLUMN_WEIGHT};
        String selection = DatabaseHelper.COLUMN_DATE + " = ?";
        String[] selectionArgs = {"goal"};
        Cursor cursor = db.query("weight", projection, selection, selectionArgs, null, null, null);

        String weightGoal = "";

        if (cursor != null && cursor.moveToFirst()) {
            int weightGoalIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT);
            if (weightGoalIndex > -1) {
                weightGoal = cursor.getString(weightGoalIndex);
            }
        }

        if (cursor != null) {
            cursor.close();
        }

        return weightGoal;
    }

    private void populateTable() {
        TableLayout tableLayoutData = findViewById(R.id.tableLayoutData);
        tableLayoutData.removeAllViews();

        // Add table headers
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundResource(R.color.gray);

        TextView textDateHeading = createHeaderTextView("Date");
        headerRow.addView(textDateHeading);

        TextView textWeightHeading = createHeaderTextView("Weight");
        headerRow.addView(textWeightHeading);

        TextView textActionsHeading = createHeaderTextView("Actions");
        headerRow.addView(textActionsHeading);

        tableLayoutData.addView(headerRow);

        // Retrieve data from the database
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String[] projection = {DatabaseHelper.COLUMN_DATE, DatabaseHelper.COLUMN_WEIGHT};
        Cursor cursor = db.query("weight", projection, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int dateCursor = cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE);
                int weightInt = cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT);
                if (weightInt > -1 && dateCursor > -1) {
                    String date = cursor.getString(dateCursor);
                    String weight = cursor.getString(weightInt);

                    if (date.equals("goal")) {
                        // Skip the row with "goal" date
                        continue;
                    }

                    TableRow dataRow = new TableRow(this);

                    TextView textDate = createDataTextView(date);
                    dataRow.addView(textDate);

                    TextView textWeight = createDataTextView(weight);
                    dataRow.addView(textWeight);

                    // Add delete button
                    Button buttonDelete = new Button(this);
                    buttonDelete.setText("Delete");
                    // Set an OnClickListener for the delete button to handle deletion logic
                    buttonDelete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.i("mytag", date);
                            int rowsDeleted = databaseHelper.deleteRow(date, weight);
                            if (rowsDeleted > 0) {
                                Toast.makeText(DataDisplayActivity.this, "Row deleted successfully", Toast.LENGTH_SHORT).show();
                                populateTable(); // Refresh the table after deleting the row
                            } else {
                                Toast.makeText(DataDisplayActivity.this, "Failed to delete row", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    dataRow.addView(buttonDelete);

                    tableLayoutData.addView(dataRow);
                }
            } while (cursor.moveToNext());
        }

        // Close the cursor after use
        if (cursor != null) {
            cursor.close();
        }
    }



    private void deleteRow(String date) {
        // Delete the corresponding row from the database based on the date value
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        String selection = DatabaseHelper.COLUMN_DATE + " = ?";
        String[] selectionArgs = {date};
        int deletedRows = db.delete("weight", selection, selectionArgs);

        if (deletedRows > 0) {
            Toast.makeText(DataDisplayActivity.this, "Row deleted successfully", Toast.LENGTH_SHORT).show();
            populateTable(); // Refresh the table after deletion
        } else {
            Toast.makeText(DataDisplayActivity.this, "Failed to delete row", Toast.LENGTH_SHORT).show();
        }
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
        textView.setPadding(8, 8, 8, 8);
        textView.setText(text);
        textView.setTextColor(ContextCompat.getColor(this, android.R.color.white));
        textView.setAllCaps(true);
        textView.setTextSize(16);
        return textView;
    }

    private TextView createDataTextView(String text) {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
        textView.setPadding(8, 8, 8, 8);
        textView.setText(text);
        textView.setTextSize(16);
        return textView;
    }

    @Override
    public void onDataAdded() {
        // Called when data is added from the dialog
        populateTable(); // Update the table after adding data
    }

    private void saveWeightGoal(String weightGoal) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_DATE, "goal"); // Use "goal" as the date to separate it from other rows
        values.put(DatabaseHelper.COLUMN_WEIGHT, weightGoal);

        long rowId = db.insert("weight", null, values);
        if (rowId != -1) {
            Toast.makeText(DataDisplayActivity.this, "Weight goal saved successfully", Toast.LENGTH_SHORT).show();
            populateTable();
        } else {
            Toast.makeText(DataDisplayActivity.this, "Failed to save weight goal", Toast.LENGTH_SHORT).show();
        }
    }
}
